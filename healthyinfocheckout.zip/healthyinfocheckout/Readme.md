# prestashop Checkout module healthyinfocheckout

checkoutModule for PrestaShop is an open source plugin that links e-commerce websites based on PrestaShop to checkout service developed by Tess

## Prerequisit

Module built for version 1.6 and v.1.7 (backward compatibility) To install, please insure to run a version listed above on your back office Check on top of screen besides the prestashop logo ! Or in Menu / Advanced parameters / informations)

## Installation

To install the module, follow these steps:

- Goto `Modules > Module manager` menu in PrestaShop Back Office.
- Click on `Upload a module` button and upload healthyinfochekcout module ZIP.
- Once zip file uploaded, module will be part of the module list , click on Install Then "Configure"

## Configuration


## USAGE & REQUIREMENTS

/!\ IMPORTANT : Once install again older version will be deleted and your configuration Access key and Secret key will be reset.

/!\ IMPORTANT : The healthy info data will stock in DBB once submit to checkout payment valid





